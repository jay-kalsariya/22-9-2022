

export const navData = {
    STORE       : 'Store',
    MAC         : 'Mac',
    IPAD        : 'iPad',
    IPHONE      : 'iPhone',
    WATCH       : 'Watch',
    AIRPODS     : 'AirPods',
    TVANDHOME   : 'TV & Home',
    ONLYONAPPLE : 'Only on Apple',
    ACCESSORIES : 'Accessories',
    SUPPORT     : 'Support'
}