
const express = require('express');
const  express = require("hbs");
const path = require("path");
const app = express();
const requstes = require("requests")
const port =3000

//built in midalware



const staticpath =path.join(__dirname,'../public');
const templatepath = path.join(__dirname,"../tempalte/views");
const partialsepath = path.join(__dirname,"../tempalte/partialse");

//to set the view  engine
app.set ("view engine","hbs");
app.set('views',templatepath);
hbs.registerpartials(); 

// app.use(express.static(staticpath));

//Template engine route
app.get("",(req,res) =>{
    res.render("index");

});


app.get("/about",(req,res) =>{
    res.render("about");

});

app.get(" * ",(req,res)=>{
    res.render("404",{
        errorcomemnt:"oops page couldn't be found",

    });

});




app.get("/",(req,res)=>{
res.send("hello for the express server");
});

app.listen(port,()=>{
    console.log(`listing the port ${port}`)
});