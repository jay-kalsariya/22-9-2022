const express  = require ("express");
const router = new express.Router();
const student = require("../models/student");

router.post("/students",async(req,res)=>{
    try {
        const user =new student(req.body);
        const createUser = await user.save();
        res.status(201).send(createUser);
    }catch(e){res.status(400).send(e);}
})

//2: we need to define to router

router.get("/jay",(req,res) =>{
    res.send("hello how are you");
  
  
  });

  module.exports = router;  