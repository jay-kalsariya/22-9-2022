const express = require("express");
require("./db/conn");
const student = require("./models/student");
 const studentRouter = require("./routers/student");
const app = express();
const port = process.env.PORT || 12000;
var bodyparser = require('body-parser');
const Router = new express.Router();

app.use(express.json());

var bodyParser = require("body-parser");
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(studentRouter);


const router = new express.Router();



//create a new student
app.post("/students", (req, res) => {
  const user = new student(req.body);

  user
    .save().then(() => {
      res.status(201).send(user);
    })
    .catch((e) => {
      res.status(400).send(e);
    })
})

router.post("/students",async(req,res)=>{
  try{
    const user = new student(req.body);
 
  const createUser =  await  user.save();
  res.status(201).send(createUser);
 
 
     }catch(e){ res.status(400).send(e);}

})



// 1: create a new router


//2: we need to define to router

router.get("/jay",(req,res) =>{
  res.send("hello how are you");


});

//3:we need to  register to router

app.use(router); 





Router.post("/students", async (req, res) => {

  console.log(req.body)
  try {
    const user = new student(req.body);

    const createUser = await user.save();
    res.send(createUser);
  } catch (e) {
    res.status(400).send(e);
  }
}); 




//read the data of registered student
router.get("/students",async (req,res)=> {
    try{
       const studentsData = await student.findOne(studentsData);
       console.log(studentsData);

        if(!studentsData){
          return res.status(404).send();

        }else{
          res.send(studentsData);
        }
    }catch(e){
        res.send(e);

    }
     
})

//get the indivisual students data using id
router.get("/jay",async (req,res)=> {

  try{

    console.log("Hi");

    const studentData = await student.findById(_id);
    console.log(studentData)
    if(!studentData){
      return res.status(404).send();
   }
    res.send(studentData);
    
  }catch(e){
    res.status(500).send(e);
  }
   
})

//delete the student by it id
router.delete("/students/:id",async(req,res)=>{
  try{

       const deleteStudent= await student.findByIdAndDelete(req.params.id);
       if(!req.params.id){
        return res.status(400).send();  
       }
       res.send(deleteStudent);
    }catch(e){
      res.status(500).send(e);


  }
})

//update  the student by it id

router.patch("/student/:id",async (req,res)=>{
  try{
    const _id = req.params.id;
   const updateStudents=  await Student.findByIdAndUpdate( _id ,req.body,{
    new:true
   });
   res.send(updateStudents);

  }catch(e){
    res.status(400).send(e);

  }

})


app.listen(port, () => {
    console.log(`connection is setup at ${port} `);
  });