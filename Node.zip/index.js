const express = require("express");
 const path = require ("path");
 const hbs = require ("hbs");
  const app = express();

//relative absolute
 // console.log(__dirname);

 const templatepath = path.join(__dirname,"../templatepath");
 const staticpath = path.join(__dirname,"../public");

//builtin middleware
  app.use(express.static(staticpath));


 app.get("/",  (req,res) => {
res.send("hello  from the express");`
`
 });


 app.get("/about",  (req,res) => {
    res.send("hello world from the About page ");
     });
    


 app.listen(3000,() =>{
    console.log("listen the port at 3000");
 });


 