
const express = require('express');
const app = express();
const port =3000;


app.get('/',(req,res)=>{
    res.write("<h1>welcome to my Home page</h1>");
    res.write("<h1>welcome to my Home page</h1>");
    res.send();

});


app.get('/about',(req,res)=>{
    res.send("welcome to my About page");

});

app.get('/contact',(req,res)=>{
    res.send("welcome to my Contact page");

});

app.get('/temp',(req,res)=>{
    res.send([ 
        { 
        id:1,
        name:"jay",
    },

    { 
        id:2,
        name:"hiii",
    },

    { 
        id:3,
        name:"uday",
    },
    { 
        id:4,
        name:"Hitesh",
    },
 ] );

});

app.get('/temp',(req,res)=>{
    res.send([ 
        { 
        id:1,
        name:"jay",
    },

    { 
        id:2,
        name:"hiii",
    },

    { 
        id:3,
        name:"uday",
    },
    { 
        id:4,
        name:"Hitesh",
    },
 ] );

});


app.listen(port,()=>{
    console.log(`listning to the port no ${port}`);
});