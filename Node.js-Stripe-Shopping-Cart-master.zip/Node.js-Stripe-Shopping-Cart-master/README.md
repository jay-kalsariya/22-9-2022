# Node.js Stripe Shopping Cart

In this repository you will find all the code for setting up Stripe payments with a shopping cart. The HTML and CSS for this project is from my free Introduction to Web Development course. The code for that course can be found [here](https://github.com/WebDevSimplified/Introduction-to-Web-Development) and the video walk-through can be found [here](https://www.youtube.com/watch?v=HfTXHrWMGVY&list=PLZlA0Gpn_vH-cEDOofOujFIknfZZpIk3a).

There is also a full video walk-through of this shopping cart available [here](https://youtu.be/mI_-1tbIXQI).